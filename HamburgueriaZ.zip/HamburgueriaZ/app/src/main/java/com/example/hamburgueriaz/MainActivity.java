package com.example.hamburgueriaz;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private TextView textViewQuantidade;
    private TextView textViewResumoPedido;
    private EditText editTextNomeCliente;
    private CheckBox checkBoxQueijo;
    private CheckBox checkBoxBacon;
    private CheckBox checkBoxOnionRings;
    private int quantidade = 0;
    private double precoQueijo = 2.0;
    private double precoBacon = 2.0;
    private double precoOnionRings = 3.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Inicializando as Views
        textViewQuantidade = findViewById(R.id.textViewQuantidade);
        textViewResumoPedido = findViewById(R.id.textViewResumoPedido);
        editTextNomeCliente = findViewById(R.id.editTextNomeCliente);
        checkBoxQueijo = findViewById(R.id.checkBoxQueijo);
        checkBoxBacon = findViewById(R.id.checkBoxBacon);
        checkBoxOnionRings = findViewById(R.id.checkBoxOnionRings);

// Configurando o botão de adição

        Button btnAdicionar = findViewById(R.id.btnAdicionar);
        btnAdicionar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                somar();
            }
        });
        // Configurando o botão de subtração
        Button btnSubtrair = findViewById(R.id.btnSubtrair);
        btnSubtrair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                subtrair();
            }
        });
        // Configurando o botão "Enviar Pedido"
        Button btnEnviarPedido = findViewById(R.id.btnEnviarPedido);
        btnEnviarPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                enviarPedido();
            }
        });
    }

    // Função para somar a quantidade
    private void somar() {
        quantidade++;
        atualizarQuantidade();
    } // Função para subtrair a quantidade, evitando valores negativos

    private void subtrair() {
        if (quantidade > 0) {
            quantidade--;
            atualizarQuantidade();
        }
    } // Função para atualizar a TextView com a quantidade atual

    private void atualizarQuantidade() {
        textViewQuantidade.setText(String.valueOf(quantidade));
    } // Função para enviar o pedido

    private void enviarPedido() {
        String nomeCliente = editTextNomeCliente.getText().toString();
        boolean temQueijo = checkBoxQueijo.isChecked();
        boolean temBacon = checkBoxBacon.isChecked();
        boolean temOnionRings = checkBoxOnionRings.isChecked();
        double precoBase = 20.0;
        // Preço base do hambúrguer
        double precoTotal = calcularPrecoTotal(precoBase, temQueijo, temBacon, temOnionRings);
        // Criar mensagem do resumo do pedido
        String mensagemResumo = "Nome do cliente: " + nomeCliente + "\n" +
                "Tem Queijo? " + (temQueijo ? "Sim" : "Não") + "\n" + "Tem Bacon? " + (temBacon ? "Sim" : "Não") + "\n" + "Tem Onion Rings? " + (temOnionRings ? "Sim" : "Não") + "\n" + "Quantidade: " + quantidade + "\n" + "Preço final: R$ " + precoTotal;
        // Criar Intent para enviar e-mail
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:"));
        // Apenas aplicativos de e-mail devem responder
        intent.putExtra(Intent.EXTRA_SUBJECT, "Pedido de " + nomeCliente);
        intent.putExtra(Intent.EXTRA_TEXT, mensagemResumo);
        if (intent.resolveActivity(getPackageManager()) != null) {
            // Se há um aplicativo de e-mail instalado, inicie a atividade
            startActivity(intent);
        }
    } // Função para calcular o preço total do pedido private

    private double calcularPrecoTotal(double precoBase, boolean temQueijo, boolean temBacon, boolean temOnionRings) {
        double precoTotal = precoBase;
        if (temQueijo) {
            precoTotal += precoQueijo;
        }
        if (temBacon) {
            precoTotal += precoBacon;
        }
        if (temOnionRings) {
            precoTotal += precoOnionRings;
        }
        return precoTotal * quantidade;
    }
}